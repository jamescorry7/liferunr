(function(){
  var $=function(i){return document.getElementById(i)};
  $('qgo').addEventListener('click',function(){
    var q=$('q').value.trim();if(!q){$('q').focus();return}
    var n=$('qn').value.trim();
    location.href='mailto:jamescorry7@gmail.com?subject='+encodeURIComponent('Running question from the LifeRunR website')+'&body='+encodeURIComponent(q+(n?'\n\nFrom: '+n:''));
  });
})();
