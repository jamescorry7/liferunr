(function(){
  var $=function(i){return document.getElementById(i)};var sel=$('pkg');if(!sel)return;
  var map={bronze:'Bronze (£29 per month)',silver:'Silver (£45 per month)',gold:'Gold (£65 per month)'};
  var m=/[?&]package=([a-z]+)/i.exec(location.search),k=m&&m[1].toLowerCase();
  if(k&&map[k]){sel.value=map[k];$('pkg-note').textContent='You chose '+map[k]+'. You can change it here.'}
  $('enq-go').addEventListener('click',function(){
    var p=sel.value||'Not sure yet',n=$('enn').value.trim(),g=$('enq-msg').value.trim();
    var body='Package: '+p+(n?'\n\nName: '+n:'')+(g?'\n\nGoal and where I am now:\n'+g:'');
    location.href='mailto:jamescorry7@gmail.com?subject='+encodeURIComponent('Coaching enquiry: '+p)+'&body='+encodeURIComponent(body);
  });
})();
