(function(){
  var $=function(i){return document.getElementById(i)};
  function f(sec){var m=Math.floor(sec/60),s=Math.round(sec%60);if(s===60){m++;s=0}return m+':'+(s<10?'0':'')+s}
  function calc(){
    var d=parseFloat($('dist').value),t=(+$('h').value||0)*3600+(+$('m').value||0)*60+(+$('s').value||0);
    if(!t){$('pk').textContent=$('pm').textContent=$('sp').textContent='–';return}
    var k=t/d;$('pk').textContent=f(k);$('pm').textContent=f(k*1.609344);$('sp').textContent=(d/(t/3600)).toFixed(1);
  }
  ['dist','h','m','s'].forEach(function(i){$(i).addEventListener('input',calc)});
  calc();
})();
(function(){
  var $=function(i){return document.getElementById(i)};
  function fmt(sec){var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=Math.round(sec%60);if(s===60){s=0;m++}if(m===60){m=0;h++}return h+':'+(m<10?'0':'')+m+':'+(s<10?'0':'')+s}
  function a(d){return 13.49681-0.000030363*d+835.7114/Math.pow(d,0.7905)}
  var T=[['5K',5],['10K',10],['10 miles',16.09344],['Half marathon',21.0975],['Marathon',42.195]];
  function pred(){
    var sel=$('pd').value;
    $('cw').classList.toggle('hid',sel!=='custom');
    var d1=sel==='custom'?(parseFloat($('cd').value)||0)*parseFloat($('cu').value):parseFloat(sel);
    var t=(+$('rh').value||0)*3600+(+$('rm').value||0)*60+(+$('rs').value||0);
    var body=$('pt');
    if(!t||!d1){body.innerHTML='<tr><td colspan="2">Enter a distance and time above.</td></tr>';return}
    var html='';
    T.forEach(function(x){var c=t*(x[1]/d1)*a(d1*1000)/a(x[1]*1000);html+='<tr><td>'+x[0]+'</td><td>'+fmt(c)+'</td></tr>'});
    body.innerHTML=html;
  }
  ['pd','cd','cu','rh','rm','rs'].forEach(function(i){$(i).addEventListener('input',pred)});
  $('pd').addEventListener('change',pred);
  pred();
})();

(function(){
  var $=function(i){return document.getElementById(i)};if(!$('bt'))return;
  function fmt(sec){var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=Math.round(sec%60);if(s===60){s=0;m++}if(m===60){m=0;h++}return h?h+':'+(m<10?'0':'')+m+':'+(s<10?'0':'')+s:m+':'+(s<10?'0':'')+s}
  function build(){
    var sel=$('bd').value;$('bcw').classList.toggle('hid',sel!=='custom');
    var km=sel==='custom'?(parseFloat($('bcd').value)||0)*parseFloat($('bcu').value):parseFloat(sel);
    var T=(+$('bh').value||0)*3600+(+$('bmin').value||0)*60+(+$('bsec').value||0);
    var body=$('bt'),sum=$('bsum'),cap=$('bcap');
    if(!(km>0)||km>100||!(T>0)){body.innerHTML='<tr><td colspan="3">Enter a distance (up to 100 km) and a goal time above.</td></tr>';sum.textContent='';cap.textContent='';return}
    var unit=parseFloat($('bu').value),u=unit===1?'km':'mile',neg=$('bst').value==='neg',half=km/2;
    function cum(d){if(!neg)return T*d/km;var p1=T/2*1.01/half,p2=T/2*0.99/half;return d<=half?d*p1:half*p1+(d-half)*p2}
    var rows=[],prev=0,n=0,m;
    for(m=unit;m<km-1e-6;m+=unit){n++;rows.push([n+' '+u,cum(m),(cum(m)-cum(prev))/(m-prev)*unit]);prev=m}
    rows.push(['Finish ('+(Math.round(km*100)/100)+' km)',T,(T-cum(prev))/(km-prev)*unit]);
    body.innerHTML=rows.map(function(r){return '<tr><td>'+r[0]+'</td><td>'+fmt(r[1])+'</td><td>'+fmt(r[2])+' per '+u+'</td></tr>'}).join('');
    var label=sel==='custom'?(Math.round(km*100)/100)+' km':$('bd').options[$('bd').selectedIndex].text;
    cap.textContent='Pace band: '+label+' in '+fmt(T)+(neg?' (slightly faster second half)':' (even pace)');
    sum.textContent='Average pace: '+fmt(T/km)+' per km ('+fmt(T/km*1.609344)+' per mile)';
  }
  ['bd','bcd','bcu','bh','bmin','bsec','bu','bst'].forEach(function(i){$(i).addEventListener('input',build)});$('bd').addEventListener('change',build);
  $('bprint').addEventListener('click',function(){document.body.classList.add('print-band');window.print();setTimeout(function(){document.body.classList.remove('print-band')},500)});
  window.addEventListener('afterprint',function(){document.body.classList.remove('print-band')});
  build();
})();
